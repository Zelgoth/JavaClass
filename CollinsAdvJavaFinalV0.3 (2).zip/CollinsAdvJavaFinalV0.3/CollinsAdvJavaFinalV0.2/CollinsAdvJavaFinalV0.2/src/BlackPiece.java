import javafx.scene.image.Image;

/******************************************************
***  BlackPiece Class
***  Michael Collins
******************************************************
*** Purpose of the class
*** Subclass of Checker.  Used to handle black game
*** pieces.  The AI will us these pieces.
******************************************************
*** Start Date: 12/1/2018
******************************************************
***Changes:
******************************************************/
public class BlackPiece extends Checker{
    private Image black = new Image("black.png");
    private Image king = new Image("blackKing.png");
    
    public BlackPiece(int location){
        /******************************************************
        ***  BlackPiece
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Constructor.  Sets up the object with the correct image
        *** and flags.  Also hands location to super.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        super(false, location);
        blackPieces++;
        setImage(black);
    }
    
    @Override
    public boolean isBlack(){
        /******************************************************
        ***  isBlack
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Here to answer the question "Are you a black piece?"
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        return true;
    }
    
    @Override
    public void kingMe(){
        /******************************************************
        ***  kingMe
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Makes this piece a king piece.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        King = true;
        setImage(king);
    }
    
    public int killMe(){
        /******************************************************
        ***  killMe
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Makes this piece a basic game tile.
        *** Method Inputs: void
        *** Return value: integer
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        setEmpty();
        blackPieces--;
        return blackPieces;
    }
}