import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

/******************************************************
***  Main Class
***  Michael Collins
******************************************************
*** Purpose of the class
*** Runs the main GUI.  Handles Game board rendering
******************************************************
*** Start Date: 11/25/2018
******************************************************
***Changes:
***12/2/2018 - moved game code to GameMaster for cleaner
***coding.
***12/2/2018 - moved game code back because FX doesn't like
***called classes to change more then one GUI item at a time.
***Still planing to pull out game code, but have to rewrite
***other classes and the "refresh" method first.
***
******************************************************/

public class CheckerBoardController {
    //built into GUI items
    @FXML private GridPane gpBoard;
    @FXML private Label lbScore;
    //built in code items
    private Checker[] tile;
    
    //game master holds all the game code.
    GameMaster gm;
    
    //game check flags
    private boolean canJump;
    
    //player selected peice
    Checker selected;
    
    //move and turn counters
    private int moves;
    private int turns;
    
    //class level image files
    private Image bKing = new Image("blackKing.png");
    private Image wKing = new Image("whiteKing.png");

    EventHandler boardEvent = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event){
                /******************************************************
                ***  handle
                ***  Michael Collins
                ******************************************************
                *** Purpose of the Method 
                *** handle is a method in EventHandler.  This will handle
                *** all the board squares in this case when ever a mouse
                *** click is released on a square.
                *** Method Inputs: MouseEvent (mouse released)
                *** Return value: void
                ******************************************************
                *** Date: 11/30/2018
                ******************************************************
                ***Change Log:
                ***12/1/2018 - removed testing code, and added a pass
                ***of event source to selected.
                ***12/3/2018 - added refresh call to update game board.
                ******************************************************/
                if(event.getSource() instanceof Checker){
                    selected((Checker)event.getSource());
                    refresh();
                }
            }
        };
    
    @FXML
    void closeSelected(ActionEvent event) {
        /******************************************************
        ***  closeSelected
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Allows the user to close the program via file menu.
        *** Method Inputs: ActionEvent
        *** Return value: void
        ******************************************************
        *** Date: 11/25/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        Platform.exit();
    }

    @FXML
    void newGameSelected(ActionEvent event) {
        /******************************************************
        ***  newGameSelected
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Allows the user to start a new game via file menu.
        *** Method Inputs: ActionEvent
        *** Return value: void
        ******************************************************
        *** Date: 11/25/2018
        ******************************************************
        ***Change Log:
        ***11/29/2018 - Added newBoard method code
        ******************************************************/
        newBoard();
    }

    @FXML
    void rulesSelected(ActionEvent event) {
        /******************************************************
        ***  rulesSelected
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Allows the user to open a rules window via the help
        *** menu.
        *** Method Inputs: ActionEvent
        *** Return value: void
        ******************************************************
        *** Date: 11/25/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
    }
    
    @FXML
    void initialize() {
        /******************************************************
        ***  initialize
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** FX GUI constructor will call this on start up.
        *** This method needs to set up the game board, and
        *** all scores.
        *** Method Inputs: ActionEvent
        *** Return value: void
        ******************************************************
        *** Date: 11/25/2018
        ******************************************************
        ***Change Log:
        ***11/29/2018 - Added newBoard method code
        ***12/3/2018 - Added a initiator for selected with a blank
        *** game piece.
        ******************************************************/
        newBoard();
        selected = new Checker();
    }
    
    private void refresh(){
        /******************************************************
        ***  refresh
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** clears and reloads the game board.
        *** Method Inputs: ActionEvent
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ***12/3/2018 - added clear to method to resolve some bugs
        *** that come from resetting the grid.
        ******************************************************/
        gpBoard.getChildren().clear();
        int j = -1;
        for(int i = 0; i < 64; i++){
            if(i%8 == 0) j++;
            gpBoard.add(tile[i], j, i%8);
        }
    }
    
    private void newBoard(){
        /******************************************************
        ***  newBoard
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Builds a new game board, and adds Mouse Listeners to
        *** every square.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 11/29/2018
        ******************************************************
        ***Change Log:
        ***12/1/2018 - moved game board loading code to the
        *** refresh method.  Restructured loading order, and
        *** pulled loading code into 2 methods:
        *** colBuildA and colBuildB
        *** This shortened the code by about 60 lines
        ******************************************************/
        
        //builds a new game board.
        tile = new Checker[64];
        
        //resets piece count
        Checker tmp = new Checker(false, -1);
        tmp.resetPieces();
        
        for(int i = 0; i < tile.length;){
            i = colBuildA(i);
            i = colBuildB(i);
        }

        //IMPORTANT!!  This adds action event handlers.
        for(int i = 0; i < 64; i++){
            tile[i].setOnMouseReleased(boardEvent);
        }
        canJump = false;
        refresh();
    }
    
    private int colBuildA(int i){
        /******************************************************
        ***  colBuildA
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Builds a game row starting at i.  passes back the
        *** next available game opening.
        *** Method Inputs: integer
        *** Return value: integer
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //builds a column starting with a black square
        int start = i;
        //adds invalid tiles
        for(; i < start + 8; i = i + 2){
            tile[i] = new Checker(false, i);
        }
        //adds valid tiles + pieces
        tile[start+1] = new BlackPiece(start+1);
        tile[start + 3] = new Checker(true, start + 3);
        tile[start + 5] = new WhitePiece(start + 5);
        tile[start + 7] = new WhitePiece(start + 7);
        return (start + 8);
    }
    
    private int colBuildB(int i){
        /******************************************************
        ***  colBuildB
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Builds a game row starting at i.  passes back the
        *** next available game opening.
        *** Method Inputs: integer
        *** Return value: integer
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //builds a column starting with a white square
        int start = i;
        //adds invalid tiles
        for(i = i + 1; i < start + 8; i = i + 2){
            tile[i] = new Checker(false, i);
        }
        //adds valid tiles + pieces
        tile[start] = new BlackPiece(start);
        tile[start + 2] = new BlackPiece(start + 2);
        tile[start + 4] = new Checker(true, start + 4);
        tile[start + 6] = new WhitePiece(start + 6);
        return (start + 8);
    }
    
    //below is game loop code
    //selected stuff
    public void selected(Checker pc){
        /******************************************************
        ***  selected
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** This is the main game controller.  It checks user
        *** selected grid squares to see if a change needs to
        *** be handled.  (Enforces game rules.)
        *** Method Inputs: Checker
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        *** 12/2/2018 - added highlightMoves, and deselect
        ***
        *** 12/3/2018 - moved deselect to top of each section.
        *** It was not functioning correctly.
        ******************************************************/
        if(pc.isWhite()){
            if(pc.selected){
                deselect();
            }
            else{
                deselect();
                pc.isSelected(true);
                selected = pc;
                highlightMoves(selected.location, true);
            }
        }
        else if(pc.selected){
            deselect();
            Checker tmp = pc;
            int tmpLoc = pc.location;
            tmp.location = selected.location;
            selected.location = tmpLoc;
            tile[tmpLoc] = selected;
            tile[tmp.location] = pc;

            
            //code to make AI go
        }
    }
    
    private void deselect(){
        /******************************************************
        ***  deselect
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** deselects a selected piece and un-highlights all
        *** available moves.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        if(selected.selected){
            selected.isSelected(false);
            highlightMoves(selected.location, false);
        }
    }
    
    private void highlightMoves(int pos, boolean check){
        /******************************************************
        ***  highlightMoves
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** highlights moves that are available to a piece.
        *** Method Inputs: integer, boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        if(canJump){
            jumpNorthH(pos, check);
            if(selected.King){
                jumpSouthH(pos, check);
            }
        }
        else{
            moveNorthH(pos, check);
            if(selected.King){
                moveSouthH(pos, check);
            }
        }
    }
    
    private void jumpNorthH(int pos,boolean check){
        /******************************************************
        ***  jumpNorthH
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** highlights possible jumps, if one is found moving
        *** north from selected piece.
        *** Method Inputs: integer, boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right jump.
        try{
            if(tile[pos + 7].isBlack()){
                if(tile[pos + 14].isValid){
                    tile[pos + 14].isSelected(check);
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpNorthH");
        }
        //checks left jump
        try{
            if(tile[pos - 9].isBlack()){
                if(tile[pos - 18].isValid){
                    tile[pos - 18].isSelected(check);
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpNorthH");
        }
    }
    
    private void jumpSouthH(int pos, boolean check){
        /******************************************************
        ***  jumpSouthH
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** highlights possible jumps, if one is found moving
        *** north from selected piece.
        *** Method Inputs: integer, boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right jump.
        try{
            if(tile[pos + 9].isWhite()){
                if(tile[pos + 18].isValid){
                    tile[pos + 18].isSelected(check);
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouthH");
        }
        //checks left jump
        try{
            if(tile[pos - 7].isWhite()){
                if(tile[pos - 14].isValid){
                    tile[pos - 14].isSelected(check);
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouthH");
        }
    }
    
    private void jumpNorth(int pos){
        /******************************************************
        ***  jumpNorth
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Counts possible jumps.  This method is to enforce
        *** game rule: If you can jump, you must.
        *** Method Inputs: integer
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right jump.
        try{
            if(tile[pos + 7].isBlack()){
                if(tile[pos + 14].isValid){
                    canJump = true;
                    moves++;
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpNorth");
        }
        //checks left jump
        try{
            if(tile[pos - 9].isBlack()){
                if(tile[pos - 18].isValid){
                    canJump = true;
                    moves++;
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpNorth");
        }
    }
    
    private void jumpSouth(int pos){
        /******************************************************
        ***  jumpSouth
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Counts possible jumps.  This method is to enforce
        *** game rule: If you can jump, you must.
        *** Method Inputs: integer
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right jump.
        try{
            if(tile[pos + 9].isWhite()){
                if(tile[pos + 18].isValid){
                    canJump = true;
                    moves++;
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouth");
        }
        //checks left jump
        try{
            if(tile[pos - 7].isWhite()){
                if(tile[pos - 14].isValid){
                    canJump = true;
                    moves++;
                }
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't jump that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouth");
        }
    }
    
    private void moveNorthH(int pos,boolean check){
        /******************************************************
        ***  moveNorthH
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** highlights possible moves, if one is found moving
        *** north from selected piece.
        *** Method Inputs: integer, boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right move
        if(pos + 7 < 64){
            if(tile[pos + 7].isValid){
                tile[pos + 7].isSelected(check);
            }
        }

        //checks left move
        if(pos - 9 >= -1){
            if(tile[pos - 9].isValid){
                tile[pos - 9].isSelected(check);
            }
        }
    }
    
    private void moveSouthH(int pos, boolean check){
        /******************************************************
        ***  moveSouthH
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** highlights possible moves, if one is found moving
        *** south from selected piece.
        *** Method Inputs: integer, boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //checks right move.
        try{
            if(tile[pos + 9].isValid){
                tile[pos + 9].isSelected(check);
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't move that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouth");
        }
        
        //checks left move
        try{
            if(tile[pos - 7].isValid){
                tile[pos - 7].isSelected(check);
            }
        }
        catch(IndexOutOfBoundsException IOFBe){
            //just means you can't move that way.
        }
        catch(Exception e){
            System.out.println("Unknow error calculating jumpSouth");
        }
    }
}