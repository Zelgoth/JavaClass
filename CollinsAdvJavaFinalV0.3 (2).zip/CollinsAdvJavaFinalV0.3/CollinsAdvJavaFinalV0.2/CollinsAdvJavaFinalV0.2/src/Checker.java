import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/******************************************************
***  Checker Class
***  Michael Collins
******************************************************
*** Purpose of the class
*** Subclass of ImageView.  Super class of game pieces.
*** This method handles all shared data between all board
*** tile types, movable and un-movable.
******************************************************
*** Start Date: 11/30/2018
******************************************************
***Changes:
*** 12/1/2018 - added location and a new constructor.
*** 12/2/2018 - added isSelected option to handle moving
*** and highlighting pieces easier.
******************************************************/

public class Checker extends ImageView{
    //double inharetaince, yay.
    //basically this is all here to be overriden
    protected static int blackPieces = 0;
    protected static int whitePieces = 0;
    //Base Image
    private Image empty = new Image("whiteCheckersGrid.png");
    private Image moveOption = new Image("moveable.png");
    
    //selected boolean
    public boolean selected;

    //king boolean
    protected boolean King;
    //moveable location boolean
    protected boolean isValid;
    //saves location, needs to be updated on move
    public int location;
    
    public Checker(){
        /******************************************************
        ***  Checker
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Constructor for Checker.  This is to be used to build
        *** a blank piece with no identity, used as a check to
        *** prevent null exceptions.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 11/30/2018
        ******************************************************
        ***Change Log:
        *** 12/3/2018 - added selected initializer to resolve
        *** more null pointer exceptions.
        ******************************************************/
        super();
        setFitWidth(100);
        setFitHeight(100);
        King = false;
        isValid = false;
        selected = false;
    }
    
    public Checker(boolean isValid, int location){
        /******************************************************
        ***  Checker
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Used to construct a Checker with a location and type
        *** identity.
        *** Method Inputs: boolean, integer
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        *** 12/2/2018 - added selected initializer.
        ******************************************************/
        super();
        this.location = location;
        this.isValid = isValid;
        selected = false;
        setFitWidth(100);
        setFitHeight(100);
        if(isValid){
            setEmpty();
        }
        else{
            setImage(new Image("blackCheckersGrid.png"));
        }
    }
    
    public void resetPieces(){
        /******************************************************
        ***  resetPieces
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** used to reset static variables to 0 when game is
        *** being restarted.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 11/30/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        blackPieces = 0;
        whitePieces = 0;
    }
    
    protected void setEmpty(){
        /******************************************************
        ***  setEmpty
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Used to reset image to the white tile image.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //sets to defalt image (white square)
        setImage(empty);
    }
    
    public void isSelected(boolean selected){
        /******************************************************
        ***  isSelected
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** used to handle moving and highlighting moves.
        *** Method Inputs: boolean
        *** Return value: void
        ******************************************************
        *** Date: 12/2/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        this.selected = selected;
        setFitWidth(100);
        setFitHeight(100);
        System.out.println("Location " + location + " is set to " + selected);
        if(selected){
            setImage(moveOption);
        }
        else{
            setImage(empty);
        }
    }
    
    public void kingMe(){
        /******************************************************
        ***  kingMe
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** makes a piece a king.  Does nothing in Checkers
        *** though.
        *** Method Inputs: void
        *** Return value: void
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        
        //just here to be Overriden.
        King = false;
    }
    
    public boolean isWhite(){
        /******************************************************
        ***  isWhite
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Here to answer the question "Are you a white piece?"
        *** Method Inputs: void
        *** Return value: boolean
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        return false;
    }
    
    public boolean isBlack(){
        /******************************************************
        ***  isBlack
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Here to answer the question "Are you a black piece?"
        *** Method Inputs: void
        *** Return value: boolean
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        return false;
    }
    
    public boolean isKing(){
        /******************************************************
        ***  isKing
        ***  Michael Collins
        ******************************************************
        *** Purpose of the Method 
        *** Here to answer the question "Are you a king piece?"
        *** Method Inputs: void
        *** Return value: boolean
        ******************************************************
        *** Date: 12/1/2018
        ******************************************************
        ***Change Log:
        ******************************************************/
        return false;
    }
}
