/******************************************************
***  GameMaster Class
***  Michael Collins
******************************************************
*** Purpose of the class
*** Handle core game coding.
******************************************************
*** Start Date: 12/2/2018
******************************************************
***Changes:
*** 12/2/2018 - moved and recoded game code from
*** CheckerBoardController to this class.
*** Then moved it back because issues...
******************************************************/
public class GameMaster {
    //holds game board
    private Checker[] tile;
    
    
    
    public GameMaster(Checker[] tile){
        this.tile = tile;

    }
    
    
}
